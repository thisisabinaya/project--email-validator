import re

def is_valid_ipv4(ip):
    parts = ip.split('.')
    if len(parts) != 4:
        return False
    for part in parts:
        try:
            if not 0 <= int(part) <= 255:
                return False
        except ValueError:
            return False
    return True

def validate_email(email):
    # Check if the email length exceeds 254 characters
    if len(email) > 254:
        return False

    # Check if '@' is in the string and it appears only once
    if email.count('@') != 1:
        return False

    local, domain = email.split('@')

    # Check the local part length
    if len(local) > 64:
        return False

    # Check for consecutive periods in local part
    if '..' in local:
        return False

    # Check for valid characters in local part
    if not re.match(r'^[a-zA-Z0-9!#$%&\'*+/=?^_`{|}~.-]+$', local):
        return False

    # Check for valid domain format
    domain_pattern = r'^(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$'
    ipv4_pattern = r'^\[([0-9]{1,3}\.){3}[0-9]{1,3}\]$'

    if re.match(domain_pattern, domain):
        return True
    elif re.match(ipv4_pattern, domain) and is_valid_ipv4(domain[1:-1]):
        return True
    else:
        return False

def process_batch_input(input_file, output_file):
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        for line in infile:
            email = line.strip()
            if validate_email(email):
                outfile.write(f"{email}\nVALID\n")
            else:
                outfile.write(f"{email}\nINVALID\n")

# Main code block
if __name__ == "__main__":
    mode = input("Enter mode (interactive/batch): ").strip().lower()
    if mode == 'interactive':
        while True:
            email = input("Enter an email address to validate (or 'exit' to quit): ")
            if email.lower() == 'exit':
                break
            if validate_email(email):
                print(f"'{email}' is a VALID email address.")
            else:
                print(f"'{email}' is NOT a valid email address.")
    elif mode == 'batch':
        input_file = input("Enter the input file name: ").strip()
        output_file = input("Enter the output file name: ").strip()
        process_batch_input(input_file, output_file)
        print(f"Batch processing completed. Check the output file '{output_file}' for results.")
        